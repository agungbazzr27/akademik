<?php 
		require_once '../koneksi.php';
		$nis = $_GET['nis'];
		$kd_mapel = $_GET['kd_mapel'];
		$sql = "DELETE FROM tbl_nilai WHERE nis='$nis' AND kd_mapel='$kd_mapel' ";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:add.php');

		}else{
			echo "Error : ".mysqli_error($conn);
		}


 ?>