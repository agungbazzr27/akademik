<?php 
		require_once '../koneksi.php';
		$nis = $_GET['nis'];
		$kd_mapel = $_GET['kd_mapel'];
		$kd_kelas = $_GET['kd_kelas'];
		$bulan = $_GET['bulan'];
		$sql = "DELETE FROM tbl_absen WHERE nis='$nis' AND kd_mapel='$kd_mapel' AND bulan='$bulan' ";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:add.php?kd_kelas='.$kd_kelas.'&kd_mapel='.$kd_mapel.'&bulan='.$bulan);

		}else{
			echo "Error : ".mysqli_error($conn);
		}


 ?>