<?php 
  date_default_timezone_set("Asia/Jakarta");
		
		$server   = "localhost";
		$usernames = "root";
		$passwords = "";
		$conn = mysqli_connect($server,$usernames,$passwords);
		$db = "akademik";
		mysqli_select_db($conn,$db);

 ?>