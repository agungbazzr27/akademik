<?php 
		require_once '../../koneksi.php';
		$kd_kelas = $_GET['kd_kelas'];
		$kd_siswa = $_GET['kd_siswa'];
		$sql = "DELETE FROM tbl_d_kelas WHERE kd_kelas='$kd_kelas' AND kd_siswa = '$kd_siswa'";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:list.php');

		}else{
			echo "Error : ".mysqli_error($conn);
		}


 ?>