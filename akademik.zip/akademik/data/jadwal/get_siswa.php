<?php 
	header('Content-Type: application/json; charset=utf-8');
	include '../../koneksi.php';
	$nis = $_GET['nis'];
	$sql = "SELECT * FROM tbl_siswa WHERE nis='$nis'";
	$result = mysqli_query($conn,$sql);
	$data = array();
	if ($result) {
		while ($k = mysqli_fetch_array($result)) {
			$data['data'] = array("nis" => $k['nis'],
			"nama" => $k['nama']);
		}
	}
	$hasil = array('status' => true, 'message' => 'Data show succes', 'respose' => $data);
 	echo json_encode($hasil);
 ?>