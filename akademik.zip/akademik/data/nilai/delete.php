<?php 
		require_once '../../koneksi.php';
		$nis = $_GET['nis'];
		$kd_mapel = $_GET['kd_mapel'];
		$kd_kelas = $_GET['kd_kelas'];
		$kd_konten = $_GET['kd_konten'];
		$sql = "DELETE FROM tbl_d_nilai WHERE nis='$nis' AND kd_mapel='$kd_mapel' AND kd_konten='$kd_konten' ";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:add.php?kd_kelas='.$kd_kelas.'&kd_mapel='.$kd_mapel.'&kd_konten='.$kd_konten);

		}else{
			echo "Error : ".mysqli_error($conn);
		}


 ?>