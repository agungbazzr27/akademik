<?php 
    $pesan_err = false;
    $kd_kelas = '';
    $kd_mapel = '';
    $kd_konten = '';
    $nama_kelas = '';
    $nama_mapel = '';
    include '../../koneksi.php';
  if (isset($_GET['kd_kelas'])) {
    $kd_kelas = $_GET['kd_kelas'];
    $kd_konten = $_GET['kd_konten'];
    $kd_mapel = $_GET['kd_mapel'];
    $sql = "SELECT * FROM tbl_kelas WHERE kd_kelas = '$kd_kelas'";
    $result = mysqli_query($conn,$sql);
    $row = mysqli_num_rows($result);
    if ($row > 0 ) {
      while ($k = mysqli_fetch_array($result)) {
         $nama_kelas = $k['nama_kelas'];
      }
    }
  }
  
  $nilai = '';
  $nis = '';
  if (isset($_POST['submit'])){
        $nilai = $_POST['nilai'];
        $nis = $_POST['nis'];
        $kd_kelas = $_POST['kd_kelas'];
        $kd_konten = $_POST['kd_konten'];
        $kd_mapel = $_POST['kd_mapel'];
        $sql = "SELECT * FROM tbl_kelas WHERE kd_kelas = '$kd_kelas'";
        $result = mysqli_query($conn,$sql);
        $row = mysqli_num_rows($result);
        if ($row > 0 ) {
          while ($k = mysqli_fetch_array($result)) {
             $nama_kelas = $k['nama_kelas'];
          }
        }
      $s = "SELECT * FROM tbl_d_nilai WHERE nis = '$nis' AND kd_kelas='$kd_kelas' AND kd_mapel='$kd_mapel' AND kd_konten='$kd_konten'";
      $q = mysqli_query($conn,$s);
      if (mysqli_num_rows($q)>0) {
        $pesan_err = true;
        $pesan = "Data nilai sudah di input";
      }else{
        $sql = "INSERT INTO tbl_d_nilai(nis,kd_kelas,kd_mapel,kd_konten,nilai) VALUES('$nis','$kd_kelas','$kd_mapel','$kd_konten','$nilai')";
        $query = mysqli_query($conn,$sql);
        $nilai = '';
        $nis = '';

        if (!$query) {
          $pesan_err = true;
          $pesan =  "Error : ".mysqli_error($conn);
        }
      }
  }

  $sql = "SELECT * FROM tbl_pelajaran WHERE kd_mapel = '$kd_mapel'";
  $result = mysqli_query($conn,$sql);
  if ($row > 0 ) {
    while ($k = mysqli_fetch_array($result)) {
       $nama_mapel = $k['nama'];
    }
  }
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>API</title>

  <!-- Favicons -->
  <link href="../../img/favicon.png" rel="icon">
  <link href="../../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../lib/bootstrap/css/bootstrap-select.css" rel="stylesheet">
  <!--external css-->
  <link href="../../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link rel="stylesheet" type="text/css" href="../../lib/bootstrap-datepicker/css/datepicker.css" />
  <!-- Custom styles for this template -->
  <link href="../../css/style.css" rel="stylesheet">
  <link href="../../css/style-responsive.css" rel="stylesheet">
  <style type="text/css">
    th,.center{
      text-align: center;
    }
  </style>

  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="../../index.php" class="logo"><b>YAZ<span>SCH</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          <!-- settings start -->
          <!-- inbox dropdown end -->
          <!-- notification dropdown start-->
          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="../../login.php">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php require_once '../../side.php'; ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper  site-min-height">
        <h3><i class="fa fa-angle-right"></i> Tambah Data Nilai</h3>
        
        <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
              <table class="table table-bordered">
                  <tbody>
                    <tr>
                      <td style="width: 60px;"><b>Kelas</b></td>
                      <td><?php echo $nama_kelas; ?></td>
                    </tr>
                    <tr>
                      <td style="width: 60px;"><b>Konten</b></td>
                      <td><?php echo $kd_konten; ?></td>
                    </tr>
                    <tr>
                      <td style="width: 60px;"><b>Mapel</b></td>
                      <td><?php echo $nama_mapel; ?></td>
                    </tr>
                  </tbody>
                </table>
                <div class=" form">
                <?php if ($pesan_err): ?>
                  <div class="alert alert-danger"><b>Perhatian!</b> <?php echo $pesan; ?></div>
                <?php endif ?>
                
                <form class="cmxform form-horizontal style-form" id="commentForm" method="post" action="add.php">
                  <div class="row">
                    <div class="col-md-3">
                      <div class="form-group">
                        <div class="col-lg-12">
                           <input class=" form-control" id="kd_mapel" value="<?php if($kd_mapel !='') echo($kd_mapel); ?>" name="kd_mapel" placeholder="kd_mapel" minlength="2" type="hidden" required />
                             <input class=" form-control" id="kd_kelas" value="<?php if($kd_kelas !='') echo($kd_kelas); ?>" name="kd_kelas" placeholder="kd_kelas" minlength="2" type="hidden" required />
                            <input class=" form-control" id="kd_konten" value="<?php if($kd_konten !='') echo($kd_konten); ?>" name="kd_konten" placeholder="kd_konten" minlength="1" type="hidden" required />
                          <select name="nis" class="selectpicker form-control">
                            <option <?php if ($nis == '') {
                              echo "selected";
                            } ?> value="">Pilih Siswa</option>
                            <?php 
                                include '../../koneksi.php';
                                  $sql = "SELECT * FROM tbl_d_kelas INNER JOIN tbl_siswa ON tbl_d_kelas.kd_siswa = tbl_siswa.nis WHERE tbl_d_kelas.kd_kelas = '$kd_kelas'";
                                  $result = mysqli_query($conn,$sql);
                                  $row = mysqli_num_rows($result);
                                  if ($row > 0 ) {
                                    while ($k = mysqli_fetch_array($result)) {
                                      if ($nis == $k['nis']) {
                                        echo "<option selected value='".$k['nis']."'>".$k['nama']."</option>";
                                      }else{
                                        echo "<option value='".$k['nis']."'>".$k['nama']."</option>";
                                      }            
                                    }
                                  }

                             ?>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-2">
                        <div class="form-group">
                          <div class="col-lg-12">
                            <input class=" form-control" id="nilai" value="<?php if($nilai !='') echo($nilai); ?>" name="nilai" placeholder="nilai" minlength="1" type="text" required />
                          </div>
                        </div>
                    </div>
                    <div class="col-md-1">
                        <div class="form-group">
                          <div class="col-lg-12">
                            <?php if (isset($_GET['nis'])): ?>
                              <button class="btn btn-theme" name="update" type="submit">Update</button>
                            <?php endif ?>
                              <?php if (!isset($_GET['nis'])): ?>
                              <button class="btn btn-theme" name="submit" type="submit">Save</button>
                              <?php endif ?>
                          </div>
                        </div>
                    </div>
                  </div>
                  
                </form>
              </div>
              <table class="table table-striped table-hover" id="my_table">
                <h4><i class="fa fa-angle-right"></i> List Nilai </h4>
                  <hr>
                  <thead>
                    <tr>
                      <th><i class="fa fa-bullhorn"></i> Nis</th>
                      <th class="hidden-phone"><i class="fa fa-question-circle"></i> Nama Siswa</th>
                      <th class="hidden-phone"><i class=" fa fa-file"></i> Mata Pelajaran</th>
                      <th class="hidden-phone"><i class=" fa fa-file"></i> Nilai</th>
                      <th class="hidden-phone"><i class=" fa fa-edit"></i> Action</th>
                    </tr>
                  </thead>
                  <tbody>
                <?php 
                    include '../../koneksi.php';
                    $sql = "SELECT n.*,s.nama as nama_siswa FROM tbl_d_nilai n INNER JOIN tbl_siswa s ON n.nis = s.nis WHERE n.kd_kelas = '$kd_kelas' AND n.kd_konten='$kd_konten' AND  n.kd_mapel='$kd_mapel' ";
                    $result = mysqli_query($conn,$sql);
                    $row = mysqli_num_rows($result);
                    $class = '';
                    if ($row > 0 ) {
                        while ($k = mysqli_fetch_array($result)) {
                            echo "<tr>
                                      <td>".$k['nis']."</td>
                                      <td class='hidden-phone'><span class='label label-success label-mini'>".$k['nama_siswa']."</span></td>
                                      <td class='center hidden-phone'>".$nama_mapel."</td>
                                      <td class='center hidden-phone'>".$k['nilai']."</td>
                                      <td class='center hidden-phone'>";
                                        echo '<button onclick="deleteModal(\''.$k['nis'].'\',\''.$k['kd_mapel'].'\',\''.$k['kd_konten'].'\',\''.$k['kd_kelas'].'\')" class="btn btn-danger btn"><i class="fa fa-trash-o "></i></button>
                                      </td>
                                    </tr>';
                      }
                    }

                    
                    ?>
                  </tbody>
                </table>
            </div>
            <div class="modal fade" id="myModalDelete" tabindex="-1" role="dialog" aria-labelledby="myModalDeleteLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalDeleteLabel">Hapus Data Nilai</h4>
                    </div>
                    <div class="modal-body">
                     <h2>Apakah anda yakin menghapus?</h2>
                     Data yang sudah di hapus tidak dapat di kembalikan.
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                      <a id="urlDelete" href=""><button type="button" class="btn btn-danger">Hapus</button></a>
                    </div>
                  </div>
                </div>
              </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>API</strong> Demo Chatbot CMS
        </p>
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
        </div>
        <a href="#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../../lib/jquery/jquery.min.js"></script>
  <script src="../../lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="../../lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="../../lib/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="../../lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../lib/jquery.scrollTo.min.js"></script>
  <script src="../../lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="../../lib/common-scripts.js"></script>
  <script src="../../lib/bootstrap/js/bootstrap-select.js"></script>
  <script src="../../lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script type="text/javascript" src="../../lib/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="../../lib/bootstrap-daterangepicker/moment.min.js"></script>
  <!--script for this page-->
  <script type="text/javascript">
    function deleteModal(nis,kd_mapel,kd_konten,kd_kelas) {
       $('#myModalDelete').modal('show');
       $("#urlDelete").attr("href", 'delete.php?nis='+nis+'&kd_mapel='+kd_mapel+'&kd_konten='+kd_konten+'&kd_kelas='+kd_kelas);
    }
    $("input#label").on({
      keydown: function(e) {
        if (e.which === 32)
          return false;
      },
      change: function() {
        this.value = this.value.replace(/\s/g, "");
      }
    });
    $(document).ready(function() {
      var dateNow = new Date();
      var oTable = $('#tgl_lahir').datepicker({ maxDate: 0,format:'dd-mm-yyyy'});
      $('#d_nilai').addClass('active');
      $('#data').click();
    });
  </script>
</body>

</html>
