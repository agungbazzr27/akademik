<?php 
	header('Content-Type: application/json; charset=utf-8');
	include '../../koneksi.php';
    $nis = $_GET['nis'];
    $tgl_lahir = $_GET['tgl_lahir'];
    $sql = "SELECT * FROM tbl_siswa WHERE nis = '$nis' AND tgl_lahir = '$tgl_lahir'";
	$result = mysqli_query($conn,$sql);
	$row = mysqli_num_rows($result);
	if ($row > 0) {
		$sql = "SELECT * FROM tbl_d_nilai WHERE nis = '$nis'";
		$result = mysqli_query($conn,$sql);
		$data = array();
		if ($result) {
			while ($k = mysqli_fetch_array($result)) {
				while ($x = mysqli_fetch_assoc($result)) {
					array_push($data, $x);
				}
				
			}
			$datax = array('data' => $data);
			$hasil = array('status' => true, 'message' => 'Data show succes', 'response' => $datax);
		}
	}else{
		$data = array();
		$datax = array('data' => $data);
		$hasil = array('status' => false, 'message' => 'Nim tidak sesuai', 'response' => $datax);
	}
	
	
 	echo json_encode($hasil);
 ?>