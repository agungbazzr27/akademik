<?php 
	require_once '../../koneksi.php';
	$nama = '';
	$tempat_lahir = '';
  $tgl_lahir = date('d-m-Y');
  $jns_kelamin = '';
  $agama = '';
  $no_tel = '';
  $alamat = '';
  $email = '';
  $spesialis = '';
  $id_guru = '';
  $pesan = '';
  $pesan_email = '';
	if (isset($_POST['submit'])){
      $nama = $_POST['nama'];
      $tempat_lahir = $_POST['tempat_lahir'];
      $jns_kelamin = $_POST['jns_kelamin'];
      $agama = $_POST['agama'];
      $no_tel = $_POST['no_tel'];
      $alamat = $_POST['alamat'];
      $email = $_POST['email'];
      $spesialis = $_POST['spesialis'];
			$tgl_lahir = date('Y-m-d',strtotime($_POST['tgl_lahir']));;
			$id_guru = uniqid();
      $s_email = "SELECT * FROM tbl_guru WHERE email = '$email'";
      $q_email = mysqli_query($conn,$s_email);

      if (mysqli_num_rows($q_email)>0) {
          $pesan_email = "Email sudah digunakan.";

        }else{
            $tahun = date('Y');
            $kd_mapel = '1021';
            $start= 1;
            $s = "SELECT * FROM tbl_guru ORDER BY nik DESC LIMIT 1";

            $q = mysqli_query($conn,$s);

            if (mysqli_num_rows($q)>0) {
              $kode ="";
              foreach ($q as $key) {
                $kode = $key['nik'];
              }
              $kde = substr($kode, 8,12);
              $start = $kde+1;
              echo "$kde, $start";
            }else{
              echo "connection_aborted :". mysqli_error($conn);
            }
            $zoro = sprintf("%04d", $start);
            $nik = $tahun.$kd_mapel.$zoro;
            $sql = "INSERT INTO tbl_guru(id_guru,nik,nama,tempat_lahir,tgl_lahir,jns_kelamin,agama,no_tel,alamat,email,spesialis) VALUES('$id_guru','$nik','$nama','$tempat_lahir','$tgl_lahir','$jns_kelamin','$agama','$no_tel','$alamat','$email','$spesialis')";

            $query = mysqli_query($conn,$sql);
            if ($query) {
              header('location:list.php');

            }else{
              $pesan =  "Error : ".mysqli_error($conn);
            }
        }
      

		
	}

	if (isset($_GET['id_guru'])) {
		$id_guru = $_GET['id_guru'];
		$sql = "SELECT * FROM tbl_guru WHERE id_guru
		='$id_guru'";

		$result = mysqli_query($conn,$sql);
		if ($result) {
			while ($k = mysqli_fetch_array($result)) {
				$nama = $k['nama'];
        $tempat_lahir = $k['tempat_lahir'];
        $jns_kelamin = $k['jns_kelamin'];
        $agama = $k['agama'];
        $no_tel = $k['no_tel'];
        $alamat = $k['alamat'];
        $email = $k['email'];
        $spesialis = $k['spesialis'];
        $tgl_lahir = date('d-m-Y',strtotime($k['tgl_lahir']));;
			}
		}
	}

	if (isset($_POST['update'])){
      $nama = $_POST['nama'];
		  $id_guru = $_POST['id_guru'];
      $tempat_lahir = $_POST['tempat_lahir'];
      $jns_kelamin = $_POST['jns_kelamin'];
      $agama = $_POST['agama'];
      $no_tel = $_POST['no_tel'];
      $alamat = $_POST['alamat'];
      $email = $_POST['email'];
      $spesialis = $_POST['spesialis'];
      $tgl_lahir = date('Y/m/d',strtotime($_POST['tgl_lahir']));;
		$sql = "UPDATE tbl_guru SET nama='$nama',tempat_lahir='$tempat_lahir',jns_kelamin='$jns_kelamin',tgl_lahir='$tgl_lahir',agama='$agama',no_tel='$no_tel', alamat = '$alamat',email='$email', spesialis = '$spesialis' WHERE id_guru='$id_guru'";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:list.php');

		}else{
			echo "Error : ".mysqli_error($conn);
		}
	}


 ?>
	

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>API</title>

  <!-- Favicons -->
  <link href="../../img/favicon.png" rel="icon">
  <link href="../../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../lib/bootstrap/css/bootstrap-select.css" rel="stylesheet">
  <!--external css-->
  <link href="../../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
   <link rel="stylesheet" type="text/css" href="../../lib/bootstrap-datepicker/css/datepicker.css" />
  <!-- Custom styles for this template -->
  <link href="../../css/style.css" rel="stylesheet">
  <link href="../../css/style-responsive.css" rel="stylesheet">

  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="../../index.php" class="logo"><b>YAZ<span>SCH</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          <!-- settings start -->
          <!-- inbox dropdown end -->
          <!-- notification dropdown start-->
          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="../../login.html">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php require_once '../../side.php'; ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> Tambah Data Guru</h3>
        
        <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
        	<h4><i class="fa fa-angle-right"></i> Form Data Guru</h4>
        	
              <div class=" form">
                <form class="cmxform form-horizontal style-form" id="commentForm" method="post" action="add.php">
                  <div class="form-group <?php if($pesan !='') echo "has-error"; ?> ">
                    <label for="label" class="control-label col-lg-2">Nama Lengkap</label>
                    <div class="col-lg-10">
                      <input class=" form-control" id="nama" value="<?php if($nama !='') echo($nama); ?>" name="nama" minlength="2" type="text" required />
                      <?php if ($pesan != ''): ?>
                				<p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan; ?></p>
           						<?php endif ?>
               		  <input class=" form-control" id="id_guru" value="<?php if(isset($_GET['id_guru'])) echo($id_guru); ?>" name="id_guru" minlength="2" type="hidden" required />
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group <?php if($pesan !='') echo "has-error"; ?> ">
                        <label for="label" class="control-label col-md-4">Tempat Lahir</label>
                        <div class="col-md-8">
                          <input class=" form-control" id="tempat_lahir" value="<?php if($tempat_lahir !='') echo($tempat_lahir); ?>" name="tempat_lahir" minlength="2" type="text" required />
                          <?php if ($pesan != ''): ?>
                            <p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan; ?></p>
                          <?php endif ?>
                        </div>
                      </div>
                    </div>
                     <div class="col-md-6">
                        <div class="form-group <?php if($pesan !='') echo "has-error"; ?> ">
                          <label for="label" class="control-label col-md-4">Tanggal Lahir</label>
                          <div class="col-md-8">
                            <input class=" form-control" id="tgl_lahir" value="<?php if($tgl_lahir !='') echo($tgl_lahir); ?>" name="tgl_lahir" type="text" required />
                            <?php if ($pesan != ''): ?>
                              <p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan; ?></p>
                            <?php endif ?>
                          </div>
                        </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group <?php if($pesan !='') echo "has-error"; ?> ">
                        <label for="label" class="control-label col-lg-4">Jenis Kelamin</label>
                        <div class="col-lg-8">
                          <select name="jns_kelamin" required="required" class="selectpicker form-control ">
                            <option value="">Pilih Jenis Kelamin</option>
                            <option <?php if ($jns_kelamin == "Laki-Laki" ) { echo "selected"; } ?> value="Laki-Laki">Laki-Laki</option>
                            <option <?php if ($jns_kelamin == "Perempuan" ) { echo "selected"; } ?> value="Perempuan">Perempuan</option>
                          </select>
                          <?php if ($pesan != ''): ?>
                            <p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan; ?></p>
                          <?php endif ?>
                        </div>
                      </div>
                    </div>
                     <div class="col-md-6">
                        <div class="form-group <?php if($pesan !='') echo "has-error"; ?> ">
                          <label for="label" class="control-label col-lg-4">Agama</label>
                          <div class="col-lg-8">
                            <input class=" form-control" id="agama" value="<?php if($agama !='') echo($agama); ?>" name="agama" minlength="2" type="text" required />
                            <?php if ($pesan != ''): ?>
                              <p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan; ?></p>
                            <?php endif ?>
                          </div>
                        </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group <?php if($pesan !='') echo "has-error"; ?> ">
                        <label for="label" class="control-label col-lg-4">Spesialis MaPel</label>
                        <div class="col-lg-8">
                          <select name="spesialis" required="required" class="selectpicker form-control ">
                            <option value="">Pilih Mata Pelajaran</option>
                            <?php 
                                include '../../koneksi.php';
                                  $sql = "SELECT * FROM tbl_pelajaran";
                                  $result = mysqli_query($conn,$sql);
                                  $row = mysqli_num_rows($result);
                                  if ($row > 0 ) {
                                    while ($k = mysqli_fetch_array($result)) {
                                      if ($kd_mapel == $k['kd_mapel']) {
                                        echo "<option selected value='".$k['kd_mapel']."'>".$k['nama']."</option>";
                                      }else{
                                        echo "<option value='".$k['kd_mapel']."'>".$k['nama']."</option>";
                                      }
                                    }
                                  }
                             ?>
                           
                          </select>
                          <?php if ($pesan != ''): ?>
                            <p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan; ?></p>
                          <?php endif ?>
                        </div>
                      </div>
                    </div>
                     <div class="col-md-6">
                        <div class="form-group <?php if($pesan_email !='') echo "has-error"; ?> ">
                          <label for="label" class="control-label col-lg-4">Email</label>
                          <div class="col-lg-8">
                            <input class=" form-control" id="email" value="<?php if($email !='') echo($email); ?>" name="email" minlength="2" type="email" required />
                            <?php if ($pesan_email != ''): ?>
                              <p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan_email; ?></p>
                            <?php endif ?>
                          </div>
                        </div>
                    </div>
                  </div>
                  <div class="form-group <?php if($pesan !='') echo "has-error"; ?> ">
                    <label for="label" class="control-label col-lg-2">Telepon</label>
                    <div class="col-lg-10">
                      <input class=" form-control" id="no_tel" value="<?php if($no_tel !='') echo($no_tel); ?>" name="no_tel" minlength="2" type="text" required />
                      <?php if ($pesan != ''): ?>
                        <p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan; ?></p>
                      <?php endif ?>
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="alamat" class="control-label col-lg-2">Alamat</label>
                    <div class="col-lg-10">
                      <textarea class="form-control " id="alamat" name="alamat" required><?php if($alamat !='') echo($alamat); ?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-lg-offset-2 col-lg-10">
                    	<?php if (isset($_GET['id_guru'])): ?>
                    		<button class="btn btn-theme" name="update" type="submit">Update</button>
                    	<?php endif ?>
                      	<?php if (!isset($_GET['id_guru'])): ?>
                    		<button class="btn btn-theme" name="submit" type="submit">Save</button>
                      	<?php endif ?>
                      <a href="list.php" class="btn btn-theme04" type="button">Cancel</a>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>API</strong> Demo Chatbot CMS
        </p>
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
        </div>
        <a href="#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../../lib/jquery/jquery.min.js"></script>
  <script src="../../lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="../../lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="../../lib/bootstrap/js/bootstrap-select.js"></script>
  <script src="../../lib/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="../../lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../lib/jquery.scrollTo.min.js"></script>
  <script src="../../lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="../../lib/common-scripts.js"></script>
  <script src="../../lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script type="text/javascript" src="../../lib/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
  <script type="text/javascript" src="../../lib/bootstrap-daterangepicker/moment.min.js"></script>
  <!--script for this page-->
  <script type="text/javascript">
  	$("input#label").on({
		  keydown: function(e) {
		    if (e.which === 32)
		      return false;
		  },
		  change: function() {
		    this.value = this.value.replace(/\s/g, "");
		  }
		});
    $(document).ready(function() {
      var dateNow = new Date();
      var oTable = $('#tgl_lahir').datepicker({ maxDate: 0,format:'dd-mm-yyyy'});
      $('#guru').addClass('active');
      $('#master').click();
    });
  </script>
</body>

</html>
