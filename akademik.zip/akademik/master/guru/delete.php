<?php 
		require_once '../../koneksi.php';
		$id_guru = $_GET['id_guru'];
		$sql = "DELETE FROM tbl_guru WHERE id_guru='$id_guru'";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:list.php');

		}else{
			echo "Error : ".mysqli_error($conn);
		}


 ?>