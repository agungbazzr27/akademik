<?php 
		require_once '../../koneksi.php';
		$id_siswa = $_GET['id_siswa'];
		$sql = "DELETE FROM tbl_siswa WHERE id_siswa='$id_siswa'";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:list.php');

		}else{
			echo "Error : ".mysqli_error($conn);
		}


 ?>