<?php 

	require_once '../../koneksi.php';
	if (isset($_POST['submit'])){
		$label = $_POST['label'];
		$message = $_POST['message'];
		$id_message = uniqid();
		$sql = "INSERT INTO tbl_message(id_message,label,message) VALUES('$id_message','$label','$message')";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			echo "Data berhasil disimpan.";

		}else{
			echo "Error : ".mysqli_error($conn);
		}
}


 ?>
	

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Yaztech School</title>

  <!-- Favicons -->
  <link href="../../img/favicon.png" rel="icon">
  <link href="../../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="../../lib/advanced-datatable/css/demo_page.css" rel="stylesheet" />
  <link href="../../lib/advanced-datatable/css/demo_table.css" rel="stylesheet" />
  <link href="../../css/style.css" rel="stylesheet">
  <link href="../../css/style-responsive.css" rel="stylesheet">

  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="/akademik/index.php" class="logo"><b>YAZ<span>SCH</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          <!-- settings start -->
          <!-- inbox dropdown end -->
          <!-- notification dropdown start-->
          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="/akademik/logout.php">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php require_once '../../side.php'; ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> Data Siswa </h3>
        <div class="row mt">
          <div class="col-md-12">
            <div class="content-panel" style="padding: 10px">
             <table class="table table-striped table-hover cf" id="my_table">
              <span class="pull-right"><a href="add.php"><button style="background-color: #4ECDC4;color: white;" class='btn'><i class='fa fa-plus'></i> Tambah Siswa</button></a></span>
                <h4><i class="fa fa-angle-right"></i> List Siswa </h4>
                <hr>
                <thead class="">
                  <tr>
                    <th><i class="fa fa-bullhorn"></i> NIS</th>
                    <th><i class="fa fa-question-circle"></i> Nama</th>
                    <th><i class="fa fa-bookmark"></i> Jenis Kelamin</th>
                    <th class="hidden-phone"><i class="fa fa-bookmark"></i> Tempat / Tgl Lahir</th>
                    <th><i class="fa fa-bookmark"></i> Agama</th>
                    <th class="hidden-phone"><i class="fa fa-bookmark"></i> Alamat</th>
                    <th class="hidden-phone"><i class="fa fa-bookmark"></i> Telepon</th>
                    <th class="hidden-phone"><i class=" fa fa-edit"></i> Action</th>
                  </tr>
                </thead>
                <tbody>
            	<?php 
        					include '../../koneksi.php';
        					$sql = "SELECT * FROM tbl_siswa";
        					$result = mysqli_query($conn,$sql);
        					$row = mysqli_num_rows($result);
        					if ($row > 0 ) {
        						while ($k = mysqli_fetch_array($result)) {
        							echo "<tr>
        				                    <td>".$k['nis']."</td>
        				                    <td><span class='label label-info label-mini'>".$k['nama']."</span></td>
        				                    <td>".$k['jns_kelamin']."</td>
        				                    <td class='hidden-phone'>".$k['tempat_lahir']." / ".$k['tgl_lahir']."</td>
                                    <td>".$k['agama']."</td>
                                    <td class='hidden-phone'>".$k['alamat_siswa']."</td>
                                    <td class='hidden-phone'>".$k['no_tel_siswa']."</td>
        				                    <td class='hidden-phone'>
        				                      <a href='add.php?id_siswa=".$k['id_siswa']."' ><button class='btn btn-primary btn' style='margin-right:5px;'><i class='fa fa-pencil'></i></button></a>";
        				                      echo '<button onclick="deleteModal(\''.$k['id_siswa'].'\')" class="btn btn-danger btn"><i class="fa fa-trash-o "></i></button>
        				                    </td>
        				                  </tr>';
        						}
        					}

                  
                  ?>
                </tbody>
              </table>
            </div>
            <!-- /content-panel -->
          </div>
          <!-- /col-md-12 -->
        </div>
        <div class="modal fade" id="myModalDelete" tabindex="-1" role="dialog" aria-labelledby="myModalDeleteLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      <h4 class="modal-title" id="myModalDeleteLabel">Hapus Data Siswa</h4>
                    </div>
                    <div class="modal-body">
                     <h2>Apakah anda yakin menghapus?</h2>
                     Data yang sudah di hapus tidak dapat di kembalikan.
                    </div>
                    <div class="modal-footer">
                      <button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
                      <a id="urlDelete" href=""><button type="button" class="btn btn-danger">Hapus</button></a>
                    </div>
                  </div>
                </div>
              </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>API</strong> Demo Chatbot CMS
        </p>
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
        </div>
        <a href="#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
 
  <script src="../../lib/jquery/jquery.min.js"></script>
  <script src="../../lib/bootstrap/js/bootstrap.min.js"></script

  <script type="text/javascript" language="javascript" src="../../lib/advanced-datatable/js/jquery-3.3.1.js"></script>
  <script type="text/javascript" language="javascript" src="../../lib/advanced-datatable/js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="../../lib/advanced-datatable/js/dataTables.bootstrap.min.js"></script>
  <!--script for this page-->
  <script type="text/javascript">
    function deleteModal(id_siswa) {
      
     $('#myModalDelete').modal('show');
     $("#urlDelete").attr("href", 'delete.php?id_siswa='+id_siswa);
    }
  	$("input#label").on({
		  keydown: function(e) {
		    if (e.which === 32)
		      return false;
		  },
		  change: function() {
		    this.value = this.value.replace(/\s/g, "");
		  }
		});
     $(document).ready(function() {
      var oTable = $('#my_table').dataTable({});
    });
  </script>
  >
  <script src="../../lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="../../lib/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="../../lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../../lib/jquery.scrollTo.min.js"></script>
  <script src="../../lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="../../lib/common-scripts.js"></script>
  <script type="text/javascript">
     $(document).ready(function() {
      $('#siswa').addClass('active');
      $('#master').click();
    });
  </script>
</body>

</html>
