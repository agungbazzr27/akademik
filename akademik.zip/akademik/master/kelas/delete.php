<?php 
		require_once '../../koneksi.php';
		$kd_kelas = $_GET['kd_kelas'];
		$sql = "DELETE FROM tbl_kelas WHERE kd_kelas='$kd_kelas'";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:list.php');

		}else{
			echo "Error : ".mysqli_error($conn);
		}


 ?>