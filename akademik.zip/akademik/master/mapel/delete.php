<?php 
		require_once '../../koneksi.php';
		$kd_mapel = $_GET['kd_mapel'];
		$sql = "DELETE FROM tbl_pelajaran WHERE kd_mapel='$kd_mapel'";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:list.php');

		}else{
			echo "Error : ".mysqli_error($conn);
		}


 ?>