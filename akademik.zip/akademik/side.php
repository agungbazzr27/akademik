<aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <li class="mt">
            <a href="/akademik/index.php">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          <li class="sub-menu" >
            <a href="javascript:;" id="master">
              <i class="fa fa-desktop"></i>
              <span>Master</span>
              </a>
            <ul class="sub">
              <li id="siswa"><a href="/akademik/master/siswa/list.php">SISWA</a></li>
              <li id="guru"><a href="/akademik/master/guru/list.php">GURU</a></li>
              <li id="mapel"><a href="/akademik/master/mapel/list.php">MATA PELAJARAN</a></li>
              <li id="kelas"><a href="/akademik/master/kelas/list.php">KELAS</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" id="nilai">
              <i class="fa fa-desktop"></i>
              <span>Nilai</span>
              </a>
            <ul class="sub">
              <li id="nilai_l"><a href="/akademik/nilai/list.php">Nilai</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" id="absen">
              <i class="fa fa-desktop"></i>
              <span>Absensi</span>
              </a>
            <ul class="sub">
              <li id="absen_l"><a href="/akademik/absen/list.php">Absensi</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;" id="data">
              <i class="fa fa-desktop"></i>
              <span>Data</span>
              </a>
            <ul class="sub">
              <li id="d_kelas"><a href="/akademik/data/kelas/list.php">Kelas</a></li>
              <li id="d_jadwal"><a href="/akademik/data/jadwal/list.php">Jadwal</a></li>
              <li id="d_nilai"><a href="/akademik/data/nilai/list.php">Nilai</a></li>
            </ul>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>