<?php 
	header('Content-Type: application/json; charset=utf-8');
	include '../koneksi.php';
	$label = $_GET['label'];
	$sql = "SELECT * FROM tbl_message WHERE label='$label'";
	$result = mysqli_query($conn,$sql);
	$data = array();
	if ($result) {
		while ($k = mysqli_fetch_array($result)) {
			$data['data'] = array("id_message" => $k['id_message'],
			"label" => $k['label'],
			"message" => $k['message']);
		}
	}
	$hasil = array('status' => true, 'message' => 'Data show succes', 'respose' => $data);
 	echo json_encode($hasil);
 ?>