<?php 

	require_once '../koneksi.php';
	$label = '';
	$pesan = '';
	$message = '';
	if (isset($_POST['submit'])){
		$label = $_POST['label'];

		$sql = "SELECT * FROM tbl_message WHERE label='$label'";
		$result = mysqli_query($conn,$sql);
		$row = mysqli_num_rows($result);
		if ($row > 0) {
			$label = $_POST['label'];
			$message = $_POST['message'];
			$pesan = "Label [ ".$label." ] sudah digunakan. silahkan menggunakan label lain.";
		}else{

			$message = $_POST['message'];
			$id_message = uniqid();
			$url = $_SERVER['HTTP_HOST']."/demo/message/get_message.php?label=".$label;
			$sql = "INSERT INTO tbl_message(id_message,label,message,url) VALUES('$id_message','$label','$message','$url')";

			$query = mysqli_query($conn,$sql);
			if ($query) {
				header('location:list.php');

			}else{
				$pesan =  "Error : ".mysqli_error($conn);
			}
		}
		
	}

	if (isset($_GET['id_message'])) {
		$id_message = $_GET['id_message'];
		$sql = "SELECT * FROM tbl_message WHERE id_message
		='$id_message'";

		$result = mysqli_query($conn,$sql);
		if ($result) {
			while ($k = mysqli_fetch_array($result)) {
				$label = $k['label'];
				$message = $k['message'];
			}
		}
	}

	if (isset($_POST['update'])){
		$label = $_POST['label'];
		$message = $_POST['message'];
		$id_message = $_POST['id_message'];
		$sql = "UPDATE tbl_message SET label='$label', message = '$message' WHERE id_message='$id_message'";

		$query = mysqli_query($conn,$sql);
		if ($query) {
			header('location:list.php');

		}else{
			echo "Error : ".mysqli_error($conn);
		}
	}


 ?>
	

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>API</title>

  <!-- Favicons -->
  <link href="../img/favicon.png" rel="icon">
  <link href="../img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Bootstrap core CSS -->
  <link href="../lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
  <link href="../lib/font-awesome/css/font-awesome.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="../css/style.css" rel="stylesheet">
  <link href="../css/style-responsive.css" rel="stylesheet">

  <!-- =======================================================
    Template Name: Dashio
    Template URL: https://templatemag.com/dashio-bootstrap-admin-template/
    Author: TemplateMag.com
    License: https://templatemag.com/license/
  ======================================================= -->
</head>

<body>
  <section id="container">
    <!-- **********************************************************************************************************************************************************
        TOP BAR CONTENT & NOTIFICATIONS
        *********************************************************************************************************************************************************** -->
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="../index.php" class="logo"><b>DASH<span>IO</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        <!--  notification start -->
        <ul class="nav top-menu">
          <!-- settings start -->
          <!-- inbox dropdown end -->
          <!-- notification dropdown start-->
          <!-- notification dropdown end -->
        </ul>
        <!--  notification end -->
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="../login.html">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    <!-- **********************************************************************************************************************************************************
        MAIN SIDEBAR MENU
        *********************************************************************************************************************************************************** -->
    <!--sidebar start-->
    <?php require_once '../side.php'; ?>
    <!--sidebar end-->
    <!-- **********************************************************************************************************************************************************
        MAIN CONTENT
        *********************************************************************************************************************************************************** -->
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        <h3><i class="fa fa-angle-right"></i> Add Message</h3>
        
        <div class="row mt">
          <div class="col-lg-12">
            <div class="form-panel">
        	<h4><i class="fa fa-angle-right"></i> Form Validations</h4>
        	
              <div class=" form">
                <form class="cmxform form-horizontal style-form" id="commentForm" method="post" action="add.php">
                  <div class="form-group <?php if($label !='') echo "has-error"; ?> ">
                    <label for="label" class="control-label col-lg-2">Label</label>
                    <div class="col-lg-10">
                      <input class=" form-control" id="label" value="<?php if($label !='') echo($label); ?>" name="label" minlength="2" type="text" required />
                      <?php if ($pesan != ''): ?>
        				<p class="help-block"><i class="fa fa-info"></i> <?php echo $pesan; ?></p>
   						<?php endif ?>
               		  <input class=" form-control" id="label" value="<?php if(isset($_GET['id_message'])) echo($id_message); ?>" name="id_message" minlength="2" type="hidden" required />
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="message" class="control-label col-lg-2">Response</label>
                    <div class="col-lg-10">
                      <textarea class="form-control " id="message" name="message" required><?php if($message !='') echo($message); ?></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-lg-offset-2 col-lg-10">
                    	<?php if (isset($_GET['id_message'])): ?>
                    		<button class="btn btn-theme" name="update" type="submit">Update</button>
                    	<?php endif ?>
                      	<?php if (!isset($_GET['id_message'])): ?>
                    		<button class="btn btn-theme" name="submit" type="submit">Save</button>
                      	<?php endif ?>
                      <a href="list.php" class="btn btn-theme04" type="button">Cancel</a>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
    <!--footer start-->
    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>API</strong> Demo Chatbot CMS
        </p>
        <div class="credits">
          <!--
            You are NOT allowed to delete the credit link to TemplateMag with free version.
            You can delete the credit link only if you bought the pro version.
            Buy the pro version with working PHP/AJAX contact form: https://templatemag.com/dashio-bootstrap-admin-template/
            Licensing information: https://templatemag.com/license/
          -->
        </div>
        <a href="#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>
    <!--footer end-->
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="../lib/jquery/jquery.min.js"></script>
  <script src="../lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="../lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="../lib/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="../lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="../lib/jquery.scrollTo.min.js"></script>
  <script src="../lib/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="../lib/common-scripts.js"></script>
  <!--script for this page-->
  <script type="text/javascript">
  	$("input#label").on({
		  keydown: function(e) {
		    if (e.which === 32)
		      return false;
		  },
		  change: function() {
		    this.value = this.value.replace(/\s/g, "");
		  }
		});
  </script>
</body>

</html>
